import React, { useState, useEffect } from 'react';
import axios from 'axios';
import "./Home.css";


let getId = "";
const Home = () => {

  const [aData, setData] = useState([]);
  const [Id,setId] = useState();
  

  
  useEffect(() => {
    axios.get('https://jsonplaceholder.typicode.com/users').then(resp => {

      setData(resp.data)
      //console.log(resp.data);
    }).catch((err) => {
      console.log(err);
    })
  },[]);

  return (
    <>
      <div className='heading'> <h1>USERS DETAILS </h1> </div>
      <div className="app-container">
        <table id='customers'>
          <tbody>
            <tr>
              <th>Name</th>
              <th>Company</th>
              <th>Blogs</th>
            </tr>

            {aData.map((currVal) => (
              <>
                <tr>
                  <td>{currVal.name}</td>
                  <td>{currVal.company.name}</td>
                  <td ><a className='link' href= {`/post/${Id}`} onClick={()=>{ getId = currVal.id; setId(currVal.id)} } >{currVal.website}</a></td> 
                </tr>
                {/* <hr></hr> */}
              </>
            ))}
          </tbody>
        </table>
      </div>

    </>
  );
}
export default Home;
export {getId};





