// const fetchApi = async () => {
//   const apiData = await fetch('https://jsonplaceholder.typicode.com/posts');
//   const data = await apiData.json();
//   console.log(data[0]);
//   temp = data[0];
//   setData(await apiData.json());

//   //setData(Data1);
// }


{/* {aData.map((currVal) => {
            return (
              <div>
                {/* <h1> {currVal.userId}</h1>
                <p>{currVal.title}</p>
                <p>{currVal.id}</p>
                <p>{currVal.body}</p>
              </div> 
            )
          })} */}


//   <div className='containerBox'>

//   <ul>
//     {aData.map(currData => <li key={currData.id}> {currData.title} </li>
//     )}
//   </ul>
// </div>
{/* <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Address</th>
              <th>Phone Number</th>
              <th>Email</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {contacts.map((contact) => (
              <Fragment>
                {editContactId === contact.id ? (
                  <EditableRow
                    editFormData={editFormData}
                    handleEditFormChange={handleEditFormChange}
                    handleCancelClick={handleCancelClick}
                  />
                ) : (
                  <ReadOnlyRow
                    contact={contact}
                    handleEditClick={handleEditClick}
                    handleDeleteClick={handleDeleteClick}
                  />
                )}
              </Fragment>
            ))}
          </tbody>
</table>

<div className='Heading'> <h1>Users Details : </h1> </div>
      <div className='contaier'>
        <div className='rowContainer'>
          <table>
            <tr>
              <th>S.No</th>
              <th>Name</th>
              <th>Company</th>
              <th align='right'>Blog posts</th>
            </tr>
          </table>
        </div>
        <div className='containerBox'>
          <ol>
            {aData.map(currData => (
              <>
                <li key={currData.id}> {currData.name} | {currData.company.name} | {currData.website} </li>
              </>
            )
            )}
          </ol>
        </div>
      </div> */}