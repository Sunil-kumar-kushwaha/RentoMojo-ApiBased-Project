import React from 'react';
import { Route, Switch } from 'react-router-dom';
import Home from './Home';
import Post from './Post';
import Error from './Error';
import PostDetail from './PostDetail';
// import P1 from './component/P1';
// import P2 from './component/P2';
// import P3 from './component/P3';
// import P4 from './component/P4';
// import P5 from './component/P5';
// import P6 from './component/P6';
// import P7 from './component/P7';
// import P8 from './component/P8';
// import P9 from './component/P9';
// import P10 from './component/P10';


const App = () => {

  return (
    <>
      <Switch>
        <Route exact path="/" component={Home} />
        <Route exact path="/post" component={Post} />
        <Route exact path="/post/1" component={PostDetail} />
        <Route exact path="/post/2" component={PostDetail} />
        <Route exact path="/post/3" component={PostDetail} />
        <Route exact path="/post/4" component={PostDetail} />
        <Route exact path="/post/5" component={PostDetail} />
        <Route exact path="/post/6" component={PostDetail} />
        <Route exact path="/post/7" component={PostDetail} />
        <Route exact path="/post/8" component={PostDetail} />
        <Route exact path="/post/9" component={PostDetail} />
        <Route exact path="/post/10" component={PostDetail} />
        <Route component={Error}/>
      </Switch>
    </>
  );
}
export default App;