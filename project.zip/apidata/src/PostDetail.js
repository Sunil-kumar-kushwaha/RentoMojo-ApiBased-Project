import React, { useState, useEffect } from 'react';
import axios from 'axios';

//import { getId } from './Home';

const PostDetail = () => {
    const [aData, setData] = useState([]);
    //const [getuserId, setuserId] = useState([]);
    useEffect(() => {
        axios.get('https://jsonplaceholder.typicode.com/posts').then(resp => {
            setData(resp.data);
            //console.log(userIdd);  
        }).catch((err) => {
            console.log(err);
        })
    });
    return (
        <div className='postContainer'>
        <h1>hello from PostDetails Page</h1>
        <h1>{aData[0].body}</h1>
            {/* {aData.map((currVal) => (
                <>
                   <h1>{currVal}</h1>
                   <li>{currVal.id}</li>
                   <li>{currVal[0].title}</li> 
                </>
            ))} */}
        </div>
    )
}

export default PostDetail;

