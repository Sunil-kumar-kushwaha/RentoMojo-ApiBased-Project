import React, { useState, useEffect } from 'react';
import axios from 'axios';
import "./Home.css";

const Post = () => {

  const [aData, setData] = useState([]);
  useEffect(() => {
    axios.get('https://jsonplaceholder.typicode.com/users').then(resp => {

      setData(resp.data)
      //console.log(resp.data);
    }).catch((err) => {
      console.log(err);
    })
  });
  return (
    <>
      <div className='heading'> <h1>Users Details : </h1> </div>
      <div className="app-container">
        <table id='customers'>
          <tbody>
            <tr>
              <th>Name</th>
              <th>Company</th>
              <th>Blogs</th>
            </tr>

            {aData.map((currVal) => (
              <>
                <tr>
                  <td>{currVal.name}</td>
                  <td>{currVal.company.name}</td>
                  <a className='link' href={currVal.website}><td >{currVal.website}</td></a>
                </tr>
                {/* <hr></hr> */}
              </>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
export default Post;