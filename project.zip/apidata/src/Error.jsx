import React from 'react'

const Error = () => {
  
  return (
    <>
      <h1>OOPS Page Not Found !</h1>
    </>
  );
}
export default Error;
